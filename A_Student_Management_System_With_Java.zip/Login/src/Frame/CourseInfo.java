
package Frame;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.SQLException;

import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;

public class CourseInfo extends javax.swing.JFrame {
private final DefaultListModel<String> listModel;
    public CourseInfo() {
        initComponents();
           txtretake.setEnabled(false);
            listModel = new DefaultListModel<>();
        jList1.setModel(listModel);
    }
      String y=null;
  Connection con;
            PreparedStatement pst;
            java.beans.Statement stm;
            
    private void loadTableColumnNames(String year) {
        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            try (Connection con = DriverManager.getConnection("jdbc:ucanaccess://D:\\Programing\\SMS Project\\Database.accdb");
                 Statement statement = con.createStatement();
                 ResultSet resultSet = statement.executeQuery("SELECT * FROM [" + year + "]")) {

                // Retrieve metadata from the result set
                ResultSetMetaData metaData = resultSet.getMetaData();
                int columnCount = metaData.getColumnCount();

                // Clear existing items in the list
                listModel.clear();

                // Add column names to the list model
                for (int i = 2; i <= columnCount-2; i++) {
                    String columnName = metaData.getColumnName(i);
                    listModel.addElement(columnName);
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
    

  private void Addcourseondb(String year) {
     if(y==null)
     {
     JOptionPane.showMessageDialog(this, "No Semester Selected");
     } else {
    try {
        String id = txtid.getText();

        Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
        con = DriverManager.getConnection("jdbc:ucanaccess://D:\\Programing\\SMS Project\\Database.accdb");

        pst = con.prepareStatement("INSERT INTO [" + year + "] (id) VALUES (?)");
        pst.setString(1, id);

        int rowsAffected = pst.executeUpdate();

        if (rowsAffected > 0) {
            txtid.setText(null);
            JOptionPane.showMessageDialog(this, "Recorded");
        } else {
            JOptionPane.showMessageDialog(this, "Failed to insert the record.");
        }
    } catch (ClassNotFoundException | SQLException ex) {
    // Check if the exception is due to a primary key violation
    if (ex.getMessage().contains("integrity constraint violation: unique constraint or index violation")) {
        JOptionPane.showMessageDialog(this, "Duplicate ID. Record with this ID already exists.");
    } else {
        ex.printStackTrace();
        Logger.getLogger(CourseInfo.class.getName()).log(Level.SEVERE, null, ex);
    }
} finally {
    // Close the resources (con and pst) in a finally block here
    try {
        if (pst != null) {
            pst.close();
        }
        if (con != null) {
            con.close();
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
}
  }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        eight = new javax.swing.JCheckBox();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtid = new javax.swing.JTextField();
        seven = new javax.swing.JCheckBox();
        six = new javax.swing.JCheckBox();
        five = new javax.swing.JCheckBox();
        four = new javax.swing.JCheckBox();
        three = new javax.swing.JCheckBox();
        second = new javax.swing.JCheckBox();
        one = new javax.swing.JCheckBox();
        txtretake = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        retakeimprove = new javax.swing.JCheckBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList<>();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        eight.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        eight.setText("8th Semester");
        eight.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eightActionPerformed(evt);
            }
        });
        getContentPane().add(eight, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 280, -1, -1));

        jPanel1.setBackground(new java.awt.Color(0, 102, 204));

        jLabel1.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Add Course Information");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(54, 54, 54)
                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(90, 90, 90))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 9, 390, 40));

        jLabel2.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel2.setText("Student Id:");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 100, 80, 20));
        getContentPane().add(txtid, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 100, 140, -1));

        seven.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        seven.setText("7th Semester");
        seven.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sevenActionPerformed(evt);
            }
        });
        getContentPane().add(seven, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 250, -1, -1));

        six.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        six.setText("6th Semester");
        six.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sixActionPerformed(evt);
            }
        });
        getContentPane().add(six, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 220, -1, -1));

        five.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        five.setText("5th Semester");
        five.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fiveActionPerformed(evt);
            }
        });
        getContentPane().add(five, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 190, -1, -1));

        four.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        four.setText("4th Semester");
        four.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fourActionPerformed(evt);
            }
        });
        getContentPane().add(four, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 280, -1, -1));

        three.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        three.setText("3rd Semester");
        three.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                threeActionPerformed(evt);
            }
        });
        getContentPane().add(three, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 250, -1, -1));

        second.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        second.setText("2nd Semester");
        second.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                secondActionPerformed(evt);
            }
        });
        getContentPane().add(second, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 220, -1, -1));

        one.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        one.setText("1st Semester");
        one.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                oneActionPerformed(evt);
            }
        });
        getContentPane().add(one, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 190, -1, -1));
        getContentPane().add(txtretake, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 340, 240, -1));

        jPanel2.setBackground(new java.awt.Color(255, 255, 204));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 390, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 60, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 390, 60));

        jPanel3.setBackground(new java.awt.Color(204, 204, 255));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 390, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 130, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 180, 390, 130));

        jPanel5.setBackground(new java.awt.Color(204, 204, 255));

        retakeimprove.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        retakeimprove.setText("Retake or Improvement");
        retakeimprove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                retakeimproveActionPerformed(evt);
            }
        });

        jList1.setLayoutOrientation(javax.swing.JList.HORIZONTAL_WRAP);
        jScrollPane1.setViewportView(jList1);

        jButton1.setText("Add");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Clear");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(90, 90, 90)
                        .addComponent(retakeimprove))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jButton1, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jButton2, javax.swing.GroupLayout.Alignment.TRAILING))))
                .addContainerGap(112, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(316, Short.MAX_VALUE)
                .addComponent(retakeimprove)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton1)
                        .addGap(18, 18, 18)
                        .addComponent(jButton2)
                        .addGap(49, 49, 49))))
        );

        getContentPane().add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 390, 510));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void eightActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eightActionPerformed
       y="8sem";
        loadTableColumnNames(y); 
          one.setSelected(false); 
          second.setSelected(false);
          three.setSelected(false);
          four.setSelected(false);
          five.setSelected(false);
          six.setSelected(false);
          seven.setSelected(false);
    }//GEN-LAST:event_eightActionPerformed

    private void sevenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sevenActionPerformed
         y="7sem";
        loadTableColumnNames(y); 
          one.setSelected(false); 
          second.setSelected(false);
          three.setSelected(false);
          four.setSelected(false);
          five.setSelected(false);
          six.setSelected(false);
          eight.setSelected(false);
    }//GEN-LAST:event_sevenActionPerformed

    private void sixActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sixActionPerformed
       y="6sem";
        loadTableColumnNames(y); 
          one.setSelected(false); 
          second.setSelected(false);
          three.setSelected(false);
          four.setSelected(false);
          five.setSelected(false);
          seven.setSelected(false);
          eight.setSelected(false);
    }//GEN-LAST:event_sixActionPerformed

    private void fiveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fiveActionPerformed
         y="5sem";
        loadTableColumnNames(y); 
          one.setSelected(false); 
          second.setSelected(false);
          three.setSelected(false);
          four.setSelected(false);
          six.setSelected(false);
          seven.setSelected(false);
          eight.setSelected(false);
    }//GEN-LAST:event_fiveActionPerformed

    private void fourActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fourActionPerformed
      y="4sem";
        loadTableColumnNames(y); 
          one.setSelected(false); 
          second.setSelected(false);
          three.setSelected(false);
          five.setSelected(false);
          six.setSelected(false);
          seven.setSelected(false);
          eight.setSelected(false);
    }//GEN-LAST:event_fourActionPerformed

    private void threeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_threeActionPerformed
      y="3sem";
        loadTableColumnNames(y); 
          one.setSelected(false); 
          second.setSelected(false);
          four.setSelected(false);
          five.setSelected(false);
          six.setSelected(false);
          seven.setSelected(false);
          eight.setSelected(false);
    }//GEN-LAST:event_threeActionPerformed

    private void secondActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_secondActionPerformed
     y="2sem";
        loadTableColumnNames(y); 
          one.setSelected(false); 
          three.setSelected(false);
          four.setSelected(false);
          five.setSelected(false);
          six.setSelected(false);
          seven.setSelected(false);
          eight.setSelected(false);
          
    }//GEN-LAST:event_secondActionPerformed

    private void oneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_oneActionPerformed
          
         y="1sem";
        loadTableColumnNames(y); 
          second.setSelected(false); 
          three.setSelected(false);
          four.setSelected(false);
          five.setSelected(false);
          six.setSelected(false);
          seven.setSelected(false);
          eight.setSelected(false);
          
    }//GEN-LAST:event_oneActionPerformed

    private void retakeimproveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_retakeimproveActionPerformed
     
        if(retakeimprove.isSelected()){
        txtretake.setEnabled(true);
        }
        else
        {
                txtretake.setEnabled(false);}
    }//GEN-LAST:event_retakeimproveActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
       Addcourseondb(y);   
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CourseInfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CourseInfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CourseInfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CourseInfo.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CourseInfo().setVisible(true);
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox eight;
    private javax.swing.JCheckBox five;
    private javax.swing.JCheckBox four;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JList<String> jList1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JCheckBox one;
    private javax.swing.JCheckBox retakeimprove;
    private javax.swing.JCheckBox second;
    private javax.swing.JCheckBox seven;
    private javax.swing.JCheckBox six;
    private javax.swing.JCheckBox three;
    private javax.swing.JTextField txtid;
    private javax.swing.JTextField txtretake;
    // End of variables declaration//GEN-END:variables
}
