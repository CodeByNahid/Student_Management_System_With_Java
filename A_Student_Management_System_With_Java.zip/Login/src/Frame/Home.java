package Frame;

import java.text.SimpleDateFormat;
import java.sql.DriverManager;
import java.beans.Statement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Date;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.Timer;
import javax.swing.*;
import java.sql.*;

public class Home extends javax.swing.JFrame {

    public Home() {
        initComponents();
       updateTimeAndDate();  
        startClock();  
         showTotalDataCount();
         showTotalDropout();
         showTotalPassout();
         showTotalTeacher();
         showTotalLecture();
         showTotalAssistant();
          updateJLabelForIndex();
    }

   AddNew addnew= new AddNew();
   Editinfo edit=new Editinfo();
   ShowInfo showinfo=new ShowInfo();
   Delete delete=new Delete();
   Certificate certi=new Certificate();
   AddNewT addt=new AddNewT();
   Cgpa cgpa=new Cgpa();
   CourseInfo coursinfo=new CourseInfo();
   StudentPayment studentpayment=new StudentPayment();
  TeacherPayment teacherpayment=new TeacherPayment();
   
   
   
   
   private void showTotalTeacher() {
        Connection con = null;
        PreparedStatement pst=null;
        ResultSet rs = null;

        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            con = DriverManager.getConnection("jdbc:ucanaccess://D:\\Programing\\SMS Project\\Database.accdb");

            // Execute a query to get the count of rows in the 'Info' table
           pst = con.prepareStatement("SELECT COUNT(*) AS rowCount FROM t_info");
          
            rs = pst.executeQuery();

            if (rs.next()) {
                // Retrieve the count and set it to the JLabel
                String rowCount = rs.getString("rowCount");
                tTeacher.setText(rowCount);
            }
        } catch (Exception e) {
            e.printStackTrace(); // Handle exceptions properly in a real application
        } finally {
            try {
                if (rs != null) rs.close();
                if (pst != null) pst.close();
                if (con != null) con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
   
   private void showTotalLecture() {
        Connection con = null;
        PreparedStatement pst=null;
        ResultSet rs = null;

        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            con = DriverManager.getConnection("jdbc:ucanaccess://D:\\Programing\\SMS Project\\Database.accdb");

            // Execute a query to get the count of rows in the 'Info' table
           pst = con.prepareStatement("SELECT COUNT(*) AS rowCount FROM t_info WHERE role = 'Lecturer'");
          
            rs = pst.executeQuery();

            if (rs.next()) {
                // Retrieve the count and set it to the JLabel
                String rowCount = rs.getString("rowCount");
                tlec.setText(rowCount);
            }
        } catch (Exception e) {
            e.printStackTrace(); // Handle exceptions properly in a real application
        } finally {
            try {
                if (rs != null) rs.close();
                if (pst != null) pst.close();
                if (con != null) con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
   
   private void showTotalAssistant() {
        Connection con = null;
        PreparedStatement pst=null;
        ResultSet rs = null;

        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            con = DriverManager.getConnection("jdbc:ucanaccess://D:\\Programing\\SMS Project\\Database.accdb");

            // Execute a query to get the count of rows in the 'Info' table
           pst = con.prepareStatement("SELECT COUNT(*) AS rowCount FROM t_info WHERE role = 'Assistant'");
          
            rs = pst.executeQuery();

            if (rs.next()) {
                // Retrieve the count and set it to the JLabel
                String rowCount = rs.getString("rowCount");
                tassi.setText(rowCount);
            }
        } catch (Exception e) {
            e.printStackTrace(); // Handle exceptions properly in a real application
        } finally {
            try {
                if (rs != null) rs.close();
                if (pst != null) pst.close();
                if (con != null) con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
   
   
    private void showTotalDropout() {
        Connection con = null;
        PreparedStatement pst=null;
        ResultSet rs = null;

        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            con = DriverManager.getConnection("jdbc:ucanaccess://D:\\Programing\\SMS Project\\Database.accdb");

            // Execute a query to get the count of rows in the 'Info' table
           pst = con.prepareStatement("SELECT COUNT(*) AS rowCount FROM Dropout");
          
            rs = pst.executeQuery();

            if (rs.next()) {
                // Retrieve the count and set it to the JLabel
                String rowCount = rs.getString("rowCount");
                tdropout.setText(rowCount);
            }
        } catch (Exception e) {
            e.printStackTrace(); // Handle exceptions properly in a real application
        } finally {
            try {
                if (rs != null) rs.close();
                if (pst != null) pst.close();
                if (con != null) con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
  
    
    
     private void showTotalPassout() {
        Connection con = null;
        PreparedStatement pst=null;
        ResultSet rs = null;

        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            con = DriverManager.getConnection("jdbc:ucanaccess://D:\\Programing\\SMS Project\\Database.accdb");

            // Execute a query to get the count of rows in the 'Info' table
           pst = con.prepareStatement("SELECT COUNT(*) AS rowCount FROM PassedOut");
          
            rs = pst.executeQuery();

            if (rs.next()) {
                // Retrieve the count and set it to the JLabel
                String rowCount = rs.getString("rowCount");
                tpassout.setText(rowCount);
            }
        } catch (Exception e) {
            e.printStackTrace(); // Handle exceptions properly in a real application
        } finally {
            try {
                if (rs != null) rs.close();
                if (pst != null) pst.close();
                if (con != null) con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    
     
   private void updateJLabelForIndex() {
       int indexToRetrieve=1;
       String url = "jdbc:ucanaccess://D:\\Programing\\SMS Project\\Database.accdb";
        try (Connection con = DriverManager.getConnection(url)) {
            String selectQuery = "SELECT spayment, totalpayT, totalsum FROM payment WHERE ID = ?";

            try (PreparedStatement selectStmt = con.prepareStatement(selectQuery)) {
                selectStmt.setInt(1, indexToRetrieve);

                try (ResultSet resultSet = selectStmt.executeQuery()) {
                    if (resultSet.next()) {
                        double spaymentValue = resultSet.getDouble("spayment");
                        double totalpayTValue = resultSet.getDouble("totalpayT");
                        double totalsumValue = resultSet.getDouble("totalsum");
                        
                        spay.setText(String.format("%.2f", spaymentValue));
totalsumj.setText(String.format("%.2f", totalsumValue));
totalpayT.setText(String.format("%.2f", totalpayTValue));


                       

                        // Do something with jLabel, e.g., add it to a JFrame or update an existing label
                    } else {
                        System.out.println("No data found for index " + indexToRetrieve);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
   }
     
     
     
     
     
     
     
    
    
    private void showTotalDataCount() {
        Connection con = null;
        PreparedStatement pst=null;
        ResultSet rs = null;

        try {
            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
            con = DriverManager.getConnection("jdbc:ucanaccess://D:\\Programing\\SMS Project\\Database.accdb");

            // Execute a query to get the count of rows in the 'Info' table
           pst = con.prepareStatement("SELECT COUNT(*) AS rowCount FROM Info");
          
            rs = pst.executeQuery();

            if (rs.next()) {
                // Retrieve the count and set it to the JLabel
                String rowCount = rs.getString("rowCount");
                tnostudent.setText(rowCount);
            }
        } catch (Exception e) {
            e.printStackTrace(); // Handle exceptions properly in a real application
        } finally {
            try {
                if (rs != null) rs.close();
                if (pst != null) pst.close();
                if (con != null) con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
   
   
   
   
 private void updateTimeAndDate() {
        // Get the current time and date
        Date now = new Date();
        SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MMM-yy");

        // Update the text of the labels
       time.setText(timeFormat.format(now));
        date.setText(dateFormat.format(now));
    }

    private void startClock() {
        // Use a Timer to update the time and date every second
        Timer timer = new Timer(1000, e -> updateTimeAndDate());
        timer.start();
    }
    

    
     
    
    
    
    
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        smangeicon = new javax.swing.JLabel();
        teachericon = new javax.swing.JLabel();
        paymenticon = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel8 = new javax.swing.JPanel();
        time = new javax.swing.JLabel();
        date = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        tnostudent = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        tpassout = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jPanel9 = new javax.swing.JPanel();
        jLabel25 = new javax.swing.JLabel();
        tdropout = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jButton11 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jPanel14 = new javax.swing.JPanel();
        jLabel35 = new javax.swing.JLabel();
        tTeacher = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jPanel15 = new javax.swing.JPanel();
        jLabel38 = new javax.swing.JLabel();
        tlec = new javax.swing.JLabel();
        jLabel40 = new javax.swing.JLabel();
        jPanel16 = new javax.swing.JPanel();
        jLabel41 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        tassi = new javax.swing.JLabel();
        jButton7 = new javax.swing.JButton();
        jLabel20 = new javax.swing.JLabel();
        jButton8 = new javax.swing.JButton();
        jLabel21 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jButton9 = new javax.swing.JButton();
        jLabel29 = new javax.swing.JLabel();
        jButton10 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jLabel30 = new javax.swing.JLabel();
        jPanel17 = new javax.swing.JPanel();
        jLabel44 = new javax.swing.JLabel();
        totalsumj = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        jPanel18 = new javax.swing.JPanel();
        jLabel47 = new javax.swing.JLabel();
        totalpayT = new javax.swing.JLabel();
        jLabel49 = new javax.swing.JLabel();
        jPanel19 = new javax.swing.JPanel();
        jLabel50 = new javax.swing.JLabel();
        jLabel51 = new javax.swing.JLabel();
        spay = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jPanel13 = new javax.swing.JPanel();
        jLabel26 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Home");
        setBackground(new java.awt.Color(117, 204, 154));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 153));

        jLabel1.setFont(new java.awt.Font("Arial", 1, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 102, 0));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Varendra University");

        jLabel2.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 102, 153));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Student Management System");

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Vu logo.png"))); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(261, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(54, 54, 54)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 489, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(134, 134, 134)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 332, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(256, 256, 256))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(16, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(6, 6, 6)
                        .addComponent(jLabel2))
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1060, 130));

        jPanel3.setBackground(new java.awt.Color(0, 102, 153));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        smangeicon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Student.png"))); // NOI18N
        smangeicon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                smangeiconMouseClicked(evt);
            }
        });
        jPanel3.add(smangeicon, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, -1, -1));

        teachericon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/teacher.png"))); // NOI18N
        teachericon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                teachericonMouseClicked(evt);
            }
        });
        jPanel3.add(teachericon, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 180, -1, 116));

        paymenticon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/money.png"))); // NOI18N
        paymenticon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                paymenticonMouseClicked(evt);
            }
        });
        jPanel3.add(paymenticon, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 328, -1, 140));

        jLabel22.setFont(new java.awt.Font("Arial", 1, 15)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(255, 255, 255));
        jLabel22.setText("Student Management");
        jPanel3.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 134, 158, 22));

        jLabel23.setFont(new java.awt.Font("Arial", 1, 15)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(255, 255, 255));
        jLabel23.setText("Payment Management");
        jPanel3.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 450, 160, 33));

        jLabel24.setFont(new java.awt.Font("Arial", 1, 15)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(255, 255, 255));
        jLabel24.setText("Teacher Management");
        jPanel3.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 290, -1, 33));

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 130, 170, 500));

        jPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        time.setBackground(new java.awt.Color(204, 204, 204));
        time.setFont(new java.awt.Font("Arial", 1, 100)); // NOI18N
        time.setForeground(new java.awt.Color(255, 255, 255));
        time.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        time.setText("0");
        jPanel8.add(time, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 190, 690, 110));

        date.setBackground(new java.awt.Color(204, 204, 204));
        date.setFont(new java.awt.Font("Arial", 1, 48)); // NOI18N
        date.setForeground(new java.awt.Color(255, 255, 255));
        date.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        date.setText("0");
        jPanel8.add(date, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 320, 690, 70));

        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/Time Date Background.png"))); // NOI18N
        jPanel8.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 499));

        jTabbedPane1.addTab("tab4", jPanel8);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/add-group (1).png"))); // NOI18N
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 190, 70, 80));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/pen.png"))); // NOI18N
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 190, 80, 80));

        jLabel6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/medal.png"))); // NOI18N
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 330, 80, 70));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/graph.png"))); // NOI18N
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 330, 80, 70));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/recruitment.png"))); // NOI18N
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 320, 70, 80));

        jButton1.setBackground(new java.awt.Color(51, 255, 153));
        jButton1.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Add New");
        jButton1.setBorder(null);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 270, 120, 30));

        jButton3.setBackground(new java.awt.Color(255, 0, 51));
        jButton3.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton3.setForeground(new java.awt.Color(255, 255, 255));
        jButton3.setText("Delete");
        jButton3.setBorder(null);
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 270, 120, 30));

        jButton2.setBackground(new java.awt.Color(51, 153, 255));
        jButton2.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Edit");
        jButton2.setBorder(null);
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 270, 120, 30));

        jButton4.setBackground(new java.awt.Color(102, 102, 255));
        jButton4.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton4.setForeground(new java.awt.Color(255, 255, 255));
        jButton4.setText("View Info.");
        jButton4.setBorder(null);
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 400, 120, 30));

        jButton5.setBackground(new java.awt.Color(255, 102, 0));
        jButton5.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton5.setForeground(new java.awt.Color(255, 255, 255));
        jButton5.setText("CGPA");
        jButton5.setBorder(null);
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 400, 120, 30));

        jButton6.setBackground(new java.awt.Color(255, 255, 153));
        jButton6.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton6.setForeground(new java.awt.Color(153, 153, 153));
        jButton6.setText("Certificate");
        jButton6.setBorder(null);
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 400, 120, 30));

        jPanel6.setBackground(new java.awt.Color(153, 153, 255));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/user (4).png"))); // NOI18N
        jPanel6.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 70, 70));

        tnostudent.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        tnostudent.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        tnostudent.setText("00");
        jPanel6.add(tnostudent, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 30, 100, -1));

        jLabel11.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel11.setText("No of total Student");
        jPanel6.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 60, -1, -1));

        jPanel2.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 60, 210, 90));

        jPanel7.setBackground(new java.awt.Color(255, 204, 204));

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/professionals.png"))); // NOI18N

        jLabel13.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel13.setText("Passed Out Student");

        tpassout.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        tpassout.setText("00");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(115, 115, 115))
            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel7Layout.createSequentialGroup()
                    .addGap(179, 179, 179)
                    .addComponent(tpassout)
                    .addContainerGap(113, Short.MAX_VALUE)))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel12, javax.swing.GroupLayout.DEFAULT_SIZE, 84, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel13)
                .addGap(14, 14, 14))
            .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel7Layout.createSequentialGroup()
                    .addGap(31, 31, 31)
                    .addComponent(tpassout)
                    .addContainerGap(31, Short.MAX_VALUE)))
        );

        jPanel2.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 60, 220, 90));

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/bin.png"))); // NOI18N
        jPanel2.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 190, 80, 70));

        jPanel9.setBackground(new java.awt.Color(204, 204, 204));
        jPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel25.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/answer.png"))); // NOI18N
        jPanel9.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 70, 70));

        tdropout.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        tdropout.setText("00");
        jPanel9.add(tdropout, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 30, -1, -1));

        jLabel27.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel27.setText("Dropped Student");
        jPanel9.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 60, 120, -1));

        jPanel2.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 60, 220, 90));

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/delete-button.png"))); // NOI18N
        jLabel16.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel16MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 0, 30, 30));

        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/book.png"))); // NOI18N
        jPanel2.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 190, 80, 70));

        jButton11.setBackground(new java.awt.Color(0, 102, 51));
        jButton11.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton11.setForeground(new java.awt.Color(255, 255, 255));
        jButton11.setText("Add Course");
        jButton11.setBorder(null);
        jButton11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton11ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton11, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 270, 120, 30));

        jTabbedPane1.addTab("tab1", jPanel2);

        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/delete-button.png"))); // NOI18N
        jLabel17.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel17MouseClicked(evt);
            }
        });
        jPanel4.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 0, 30, 30));

        jPanel10.setBackground(new java.awt.Color(255, 255, 255));
        jPanel10.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel14.setBackground(new java.awt.Color(153, 243, 214));
        jPanel14.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel35.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/no teacher.png"))); // NOI18N
        jPanel14.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 70, 70));

        tTeacher.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        tTeacher.setText("00");
        jPanel14.add(tTeacher, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 30, -1, -1));

        jLabel37.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel37.setText("No of total Teacher");
        jPanel14.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(61, 60, 140, -1));

        jPanel10.add(jPanel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 60, 210, 90));

        jPanel15.setBackground(new java.awt.Color(102, 102, 255));
        jPanel15.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel38.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/lecture.png"))); // NOI18N
        jPanel15.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 10, 70, 70));

        tlec.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        tlec.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        tlec.setText("00");
        jPanel15.add(tlec, new org.netbeans.lib.awtextra.AbsoluteConstraints(156, 30, 50, -1));

        jLabel40.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel40.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel40.setText("Total Lecturer");
        jPanel15.add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 60, 110, -1));

        jPanel10.add(jPanel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 60, 220, 90));

        jPanel16.setBackground(new java.awt.Color(204, 204, 255));

        jLabel41.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/assistant.png"))); // NOI18N

        jLabel42.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel42.setText("Total Assistant Teac.");

        tassi.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        tassi.setText("00");

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addComponent(jLabel41, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel42)
                .addContainerGap(13, Short.MAX_VALUE))
            .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel16Layout.createSequentialGroup()
                    .addGap(179, 179, 179)
                    .addComponent(tassi)
                    .addContainerGap(15, Short.MAX_VALUE)))
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel41, javax.swing.GroupLayout.DEFAULT_SIZE, 84, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel16Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel42)
                .addGap(14, 14, 14))
            .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel16Layout.createSequentialGroup()
                    .addGap(31, 31, 31)
                    .addComponent(tassi)
                    .addContainerGap(31, Short.MAX_VALUE)))
        );

        jPanel10.add(jPanel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 60, 220, 90));

        jButton7.setBackground(new java.awt.Color(102, 102, 255));
        jButton7.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton7.setForeground(new java.awt.Color(255, 255, 255));
        jButton7.setText("View Info.");
        jButton7.setBorder(null);
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        jPanel10.add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 400, 120, 30));

        jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/recruitment.png"))); // NOI18N
        jPanel10.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 320, 70, 80));

        jButton8.setBackground(new java.awt.Color(51, 255, 153));
        jButton8.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton8.setForeground(new java.awt.Color(255, 255, 255));
        jButton8.setText("Add New");
        jButton8.setBorder(null);
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        jPanel10.add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 270, 120, 30));

        jLabel21.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/add-group (1).png"))); // NOI18N
        jPanel10.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 190, 70, 80));

        jLabel28.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/pen.png"))); // NOI18N
        jPanel10.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 190, 80, 80));

        jButton9.setBackground(new java.awt.Color(51, 153, 255));
        jButton9.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton9.setForeground(new java.awt.Color(255, 255, 255));
        jButton9.setText("Edit");
        jButton9.setBorder(null);
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        jPanel10.add(jButton9, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 270, 120, 30));

        jLabel29.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/bin.png"))); // NOI18N
        jPanel10.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 190, 80, 70));

        jButton10.setBackground(new java.awt.Color(255, 0, 51));
        jButton10.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jButton10.setForeground(new java.awt.Color(255, 255, 255));
        jButton10.setText("Delete");
        jButton10.setBorder(null);
        jButton10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton10ActionPerformed(evt);
            }
        });
        jPanel10.add(jButton10, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 270, 120, 30));

        jPanel4.add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 890, 500));

        jTabbedPane1.addTab("tab2", jPanel4);

        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/delete-button.png"))); // NOI18N
        jLabel19.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel19MouseClicked(evt);
            }
        });
        jPanel5.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 0, 30, 30));

        jPanel11.setBackground(new java.awt.Color(255, 255, 255));
        jPanel11.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel30.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jLabel30.setText("Student Semester Fee");
        jPanel11.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 390, 170, -1));

        jPanel17.setBackground(new java.awt.Color(204, 204, 204));
        jPanel17.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel44.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/wallet.png"))); // NOI18N
        jPanel17.add(jLabel44, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 70, 70));

        totalsumj.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        totalsumj.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        totalsumj.setText("00");
        jPanel17.add(totalsumj, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 30, 110, -1));

        jLabel46.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel46.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel46.setText("Total Balance");
        jPanel17.add(jLabel46, new org.netbeans.lib.awtextra.AbsoluteConstraints(61, 60, 140, -1));

        jPanel11.add(jPanel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 60, 210, 90));

        jPanel18.setBackground(new java.awt.Color(204, 204, 255));
        jPanel18.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel47.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/payment-method.png"))); // NOI18N
        jPanel18.add(jLabel47, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 70, 70));

        totalpayT.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        totalpayT.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        totalpayT.setText("00");
        jPanel18.add(totalpayT, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 30, 120, -1));

        jLabel49.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel49.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel49.setText("Total Paid");
        jPanel18.add(jLabel49, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 60, 110, -1));

        jPanel11.add(jPanel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 60, 220, 90));

        jPanel19.setBackground(new java.awt.Color(255, 255, 204));

        jLabel50.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/fees.png"))); // NOI18N

        jLabel51.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel51.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel51.setText("Total Semester Fee");

        spay.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        spay.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        spay.setText("00");

        javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
        jPanel19.setLayout(jPanel19Layout);
        jPanel19Layout.setHorizontalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addComponent(jLabel50, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel51)
                    .addComponent(spay, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(20, Short.MAX_VALUE))
        );
        jPanel19Layout.setVerticalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel50, javax.swing.GroupLayout.DEFAULT_SIZE, 84, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel19Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(spay)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel51)
                .addGap(14, 14, 14))
        );

        jPanel11.add(jPanel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 60, 220, 90));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/money-insurance.png"))); // NOI18N
        jLabel10.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel10MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
                .addContainerGap(16, Short.MAX_VALUE)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
                .addContainerGap(16, Short.MAX_VALUE)
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
        );

        jPanel11.add(jPanel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 280, 100, 100));

        jLabel26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/erfde.png"))); // NOI18N
        jLabel26.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel26MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel26)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel26, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        jPanel11.add(jPanel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 280, 100, 100));

        jLabel31.setFont(new java.awt.Font("Arial", 1, 16)); // NOI18N
        jLabel31.setText("Techer Payment");
        jPanel11.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 390, 130, -1));

        jPanel5.add(jPanel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 890, 500));

        jTabbedPane1.addTab("tab3", jPanel5);

        getContentPane().add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 100, 890, 530));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
      addnew.setVisible(true);
      addnew.setDefaultCloseOperation((JFrame.DISPOSE_ON_CLOSE));
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
  edit.setVisible(true);
      edit.setDefaultCloseOperation((JFrame.DISPOSE_ON_CLOSE));
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
       
        delete.setVisible(true);
      delete.setDefaultCloseOperation((JFrame.DISPOSE_ON_CLOSE));
        
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
     showinfo.setVisible(true);
      showinfo.setDefaultCloseOperation((JFrame.DISPOSE_ON_CLOSE));
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
    
     cgpa.setVisible(true);
      cgpa.setDefaultCloseOperation((JFrame.DISPOSE_ON_CLOSE));
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        certi.setVisible(true);
      certi.setDefaultCloseOperation((JFrame.DISPOSE_ON_CLOSE));
    }//GEN-LAST:event_jButton6ActionPerformed

    private void smangeiconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_smangeiconMouseClicked
      
              
                smangeicon.setIcon(new ImageIcon("D:/Programing/Sms 2o/Login/src/Image/StudentD.png"));
                teachericon.setIcon(new ImageIcon("D:/Programing/Sms 2o/Login/src/Image/teacher.png"));
                paymenticon.setIcon(new ImageIcon("D:/Programing/Sms 2o/Login/src/Image/money.png"));
                jTabbedPane1.setSelectedIndex(1);
           showTotalDataCount();
           showTotalDropout();
           showTotalPassout();
    }//GEN-LAST:event_smangeiconMouseClicked

    private void teachericonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_teachericonMouseClicked
          
              
                smangeicon.setIcon(new ImageIcon("D:/Programing/Sms 2o/Login/src/Image/Student.png"));
                teachericon.setIcon(new ImageIcon("D:/Programing/Sms 2o/Login/src/Image/teacherD.png"));
                paymenticon.setIcon(new ImageIcon("D:/Programing/Sms 2o/Login/src/Image/money.png"));
                         jTabbedPane1.setSelectedIndex(2);
                          showTotalTeacher();
         showTotalLecture();
         showTotalAssistant();
        
    }//GEN-LAST:event_teachericonMouseClicked

    private void paymenticonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_paymenticonMouseClicked
      smangeicon.setIcon(new ImageIcon("D:/Programing/Sms 2o/Login/src/Image/Student.png"));
                teachericon.setIcon(new ImageIcon("D:/Programing/Sms 2o/Login/src/Image/teacher.png"));
                paymenticon.setIcon(new ImageIcon("D:/Programing/Sms 2o/Login/src/Image/paymentD.png"));
                 jTabbedPane1.setSelectedIndex(3);
                  updateJLabelForIndex();
    }//GEN-LAST:event_paymenticonMouseClicked

    private void jLabel16MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel16MouseClicked
        smangeicon.setIcon(new ImageIcon("D:/Programing/Sms 2o/Login/src/Image/Student.png"));
                teachericon.setIcon(new ImageIcon("D:/Programing/Sms 2o/Login/src/Image/teacher.png"));
                paymenticon.setIcon(new ImageIcon("D:/Programing/Sms 2o/Login/src/Image/money.png"));
                 jTabbedPane1.setSelectedIndex(0);
    }//GEN-LAST:event_jLabel16MouseClicked

    private void jLabel17MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel17MouseClicked
       smangeicon.setIcon(new ImageIcon("D:/Programing/Sms 2o/Login/src/Image/Student.png"));
                teachericon.setIcon(new ImageIcon("D:/Programing/Sms 2o/Login/src/Image/teacher.png"));
                paymenticon.setIcon(new ImageIcon("D:/Programing/Sms 2o/Login/src/Image/money.png"));
                 jTabbedPane1.setSelectedIndex(0);
    }//GEN-LAST:event_jLabel17MouseClicked

    private void jLabel19MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel19MouseClicked
       smangeicon.setIcon(new ImageIcon("D:/Programing/Sms 2o/Login/src/Image/Student.png"));
                teachericon.setIcon(new ImageIcon("D:/Programing/Sms 2o/Login/src/Image/teacher.png"));
                paymenticon.setIcon(new ImageIcon("D:/Programing/Sms 2o/Login/src/Image/money.png"));
                 jTabbedPane1.setSelectedIndex(0);
    }//GEN-LAST:event_jLabel19MouseClicked

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
       addt.setVisible(true);
      addt.setDefaultCloseOperation((JFrame.DISPOSE_ON_CLOSE));
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton10ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton10ActionPerformed

    private void jButton11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton11ActionPerformed
   coursinfo.setVisible(true);
   coursinfo.setDefaultCloseOperation((JFrame.DISPOSE_ON_CLOSE));
    }//GEN-LAST:event_jButton11ActionPerformed

    private void jLabel10MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel10MouseClicked
       teacherpayment.setVisible(true);
      teacherpayment.setDefaultCloseOperation((JFrame.DISPOSE_ON_CLOSE));
    }//GEN-LAST:event_jLabel10MouseClicked

    private void jLabel26MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel26MouseClicked
       studentpayment.setVisible(true);
     studentpayment.setDefaultCloseOperation((JFrame.DISPOSE_ON_CLOSE));
        
    }//GEN-LAST:event_jLabel26MouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Home().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel date;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton10;
    private javax.swing.JButton jButton11;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel paymenticon;
    private javax.swing.JLabel smangeicon;
    private javax.swing.JLabel spay;
    private javax.swing.JLabel tTeacher;
    private javax.swing.JLabel tassi;
    private javax.swing.JLabel tdropout;
    private javax.swing.JLabel teachericon;
    private javax.swing.JLabel time;
    private javax.swing.JLabel tlec;
    private javax.swing.JLabel tnostudent;
    private javax.swing.JLabel totalpayT;
    private javax.swing.JLabel totalsumj;
    private javax.swing.JLabel tpassout;
    // End of variables declaration//GEN-END:variables
}
