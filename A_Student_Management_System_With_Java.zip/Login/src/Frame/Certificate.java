package Frame;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.graphics.image.LosslessFactory;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import org.apache.pdfbox.pdmodel.font.PDType0Font;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Certificate extends javax.swing.JFrame {

    public Certificate() {
        initComponents();
    }
    
    private void addToDashboardTable(String studentId) {
        try (Connection connection = DriverManager.getConnection("jdbc:ucanaccess://D:\\Programing\\SMS Project\\Database.accdb")) {
            String insertQuery = "INSERT INTO PassedOut (id) VALUES (?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {
                preparedStatement.setString(1, studentId);
                preparedStatement.executeUpdate();

              
            }
        } catch (Exception e) {
            e.printStackTrace(); // Handle exceptions properly in a real application
        }
     }
    
    
    
private void fetchDataFromDatabaseAndExportToPDF(String studentId) {
        try (Connection connection = DriverManager.getConnection("jdbc:ucanaccess://D:\\Programing\\SMS Project\\Database.accdb")) {
            String query = "SELECT * FROM Info WHERE id=?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, studentId);
                ResultSet resultSet = preparedStatement.executeQuery();
                if (resultSet.next()) {
                    // Fetch data
                    String name = resultSet.getString("name");
                    String gender = resultSet.getString("gender");
                    String fatherName = resultSet.getString("fatherName");
                    String phoneNo = resultSet.getString("phone_no");
                    String address = resultSet.getString("address");
                    String dept=resultSet.getString("department");
String c=resultSet.getString("cgpa");



    
    double cgpaValue = Double.parseDouble(c);

   
    String formattedCgpa = String.format("%.1f", cgpaValue);

    


                    
                    exportToPDF(name, gender, fatherName, phoneNo, address,studentId,dept,formattedCgpa);
                     addToDashboardTable(studentId);
                } else {
                    JOptionPane.showMessageDialog(this, "ID not found");
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }


 private void exportToPDF(String name, String gender, String fatherName, String phoneNo, String address, String id, String d,String cgpa) {
 try (PDDocument document = new PDDocument()) {
    PDPage page = new PDPage();
    document.addPage(page);

    try (PDPageContentStream contentStream = new PDPageContentStream(document, page)) {
        
 LocalDate currentDate = LocalDate.now();
 DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MMM-yy");
String formattedDate = currentDate.format(formatter);


// Load the image
        BufferedImage logoImage = ImageIO.read(new File("D://Programing//Sms 2o//Login//src//Image//Vu logo.png"));

        // Convert BufferedImage to PDImageXObject
        PDImageXObject pdImage = LosslessFactory.createFromImage(document, logoImage);

        // Get the dimensions of the page
        float pageWidth = page.getMediaBox().getWidth();
        float pageHeight = page.getMediaBox().getHeight();

        // Calculate the center position for the image
        float centerX = (pageWidth - pdImage.getWidth() * 0.5f) / 2;
        float logoY = pageHeight - pdImage.getHeight() * 0.5f - 20; // Adjust the offset based on your layout

        // Draw the image at the top center
        float scale = 0.5f; // Adjust the scale factor as needed
        contentStream.drawImage(pdImage, centerX, logoY, pdImage.getWidth() * scale, pdImage.getHeight() * scale);

        // Draw the title below the logo
        contentStream.beginText();
        contentStream.setFont(PDType0Font.load(document, new File("D:\\Programing\\Sms 2o\\Login\\Roboto-Regular.ttf")), 18);
        contentStream.newLineAtOffset(centerX - 60, logoY - 50); // Adjust the offset based on your layout

        contentStream.showText("Varendra University");
        contentStream.endText();

        // Begin the text block after drawing the image and title
        contentStream.beginText();
        contentStream.setFont(PDType0Font.load(document, new File("D:\\Programing\\Sms 2o\\Login\\Oswald-VariableFont_wght.ttf")), 16);

        float textYStart = logoY - 70; // Adjust the starting Y position below the title
        float leading = 15; // Adjust the leading (line spacing)
float leftMargin = 50; // Adjust the left margin as needed

// Write data to PDF with proper formatting
contentStream.newLineAtOffset(leftMargin, textYStart);
contentStream.showText("This is to certify that "+name+" has successfully completed");
contentStream.newLineAtOffset(0, -leading-4);
contentStream.showText("the requirements for BSC in " + d+" on " + formattedDate +" with CGPA-" + cgpa + "." );
contentStream.newLineAtOffset(0, -leading-4);
contentStream.showText("May Allah bless her for future progress.");

// Move to the next line before starting the footer
contentStream.newLineAtOffset(centerX - 50, -leading * 2);

// Footer
contentStream.showText("Osman Gani");
contentStream.newLineAtOffset(0, -leading-4);
contentStream.showText("Dr. M. Osman Gani Talukder");
contentStream.newLineAtOffset(0, -leading-4);
contentStream.showText("Vice Chancellor");
contentStream.newLineAtOffset(0, -leading-4);
contentStream.showText("Varendra University");

contentStream.endText();

 // Close the text block
    }

    // Save the document
    String filePath = "D:\\Programing\\SMS Project\\" + id + ".pdf";
    document.save(filePath);
    JOptionPane.showMessageDialog(this, "Data exported to PDF successfully");
    
    
    
   
    
    

} catch (IOException e) {
    e.printStackTrace();
}

 }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        txtid = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel2.setBackground(new java.awt.Color(255, 204, 153));
        jPanel2.setPreferredSize(new java.awt.Dimension(570, 3));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 540, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 10, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 540, 10));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        txtid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtidActionPerformed(evt);
            }
        });

        jButton1.setBackground(new java.awt.Color(255, 204, 51));
        jButton1.setText("Genarate Certificate");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/quality.png"))); // NOI18N

        jLabel2.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel2.setText("Enter the ID of Candidate");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(140, 140, 140)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.CENTER)
                    .addComponent(jLabel2)
                    .addComponent(txtid, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1))
                .addContainerGap(160, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtid, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(51, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-4, 6, 540, 420));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
      
         String studentId = txtid.getText();
                fetchDataFromDatabaseAndExportToPDF(studentId);
                 
        
        
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void txtidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtidActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtidActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Certificate.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Certificate.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Certificate.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Certificate.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Certificate().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JTextField txtid;
    // End of variables declaration//GEN-END:variables
}
