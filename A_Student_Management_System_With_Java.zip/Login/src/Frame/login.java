package Frame;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.text.JTextComponent;

public class login extends javax.swing.JFrame {

    private final Home homePage;
     private final String expectedUserName = null;
    private String expectedPassword=null;
    
    public login() {
        initComponents();
         homePage = new Home();
        setPlaceholderP(txtPassword, "password");
         setPlaceholder(txtUsername, "username");
         loginButton.requestFocusInWindow();
    }

     
private void setPlaceholder(JTextComponent field, String placeholder) {
    Font originalFont = field.getFont();
    Font italicFont = new Font(originalFont.getName(), Font.ITALIC, originalFont.getSize());

    field.setFont(italicFont);
    field.setForeground(Color.GRAY);
    field.setText(placeholder);

    field.addFocusListener(new FocusAdapter() {
        @Override
        public void focusGained(FocusEvent e) {
            if (field.getText().equals(placeholder)) {
                field.setText("");
                field.setFont(originalFont);
                field.setForeground(Color.BLACK);
            }
        }

        @Override
        public void focusLost(FocusEvent e) {
            if (field.getText().isEmpty()) {
                field.setFont(italicFont);
                field.setForeground(Color.GRAY);
                field.setText(placeholder);
            }
        }
    });
}


private void setPlaceholderP(JPasswordField field, String placeholder) {
    field.setEchoChar((char) 0); // Display placeholder text
    Font font=field.getFont();
    font=font.deriveFont(Font.ITALIC);
    field.setFont(font);
    field.setForeground(Color.GRAY);
    field.setText(placeholder);
    
    field.addFocusListener(new FocusAdapter() {
        @Override
        public void focusGained(FocusEvent e) {
           
            if (Arrays.equals(field.getPassword(), placeholder.toCharArray())) {
                field.setText("");
                field.setForeground(Color.BLACK);
                field.setEchoChar('*'); // Set password character
            }
        }

        @Override
        public void focusLost(FocusEvent e) {
            if (field.getPassword().length == 0) {
                field.setForeground(Color.GRAY);
                field.setText(placeholder);
                field.setEchoChar((char) 0); // Display placeholder text
            }
        }
    });
}

private void fetchDataFromDatabase(String username) {
    
        try (Connection connection = DriverManager.getConnection("jdbc:ucanaccess://D:\\Programing\\SMS Project\\Database.accdb")) {
            String query = "SELECT * FROM logininfo WHERE userName=?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, username);

                ResultSet resultSet = preparedStatement.executeQuery();
                if (resultSet.next()) {
                    expectedPassword=(resultSet.getString("password"));
                    
                } else {
                    JOptionPane.showMessageDialog(this, "User not found");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }





    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtUsername = new javax.swing.JTextField();
        loginButton = new javax.swing.JButton();
        txtPassword = new javax.swing.JPasswordField();
        forget = new javax.swing.JButton();
        Name1 = new javax.swing.JLabel();
        Name = new javax.swing.JLabel();
        adminicon = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Admin Login");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        txtUsername.setBackground(new java.awt.Color(255, 204, 255));
        txtUsername.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtUsernameActionPerformed(evt);
            }
        });
        getContentPane().add(txtUsername, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 160, 130, 30));

        loginButton.setBackground(new java.awt.Color(0, 51, 255));
        loginButton.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        loginButton.setForeground(new java.awt.Color(255, 255, 255));
        loginButton.setText("Login");
        loginButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginButtonActionPerformed(evt);
            }
        });
        getContentPane().add(loginButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 290, 70, 30));

        txtPassword.setBackground(new java.awt.Color(204, 204, 255));
        txtPassword.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPasswordActionPerformed(evt);
            }
        });
        getContentPane().add(txtPassword, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 220, 130, 30));

        forget.setBackground(new java.awt.Color(255, 255, 153));
        forget.setFont(new java.awt.Font("Arial", 2, 8)); // NOI18N
        forget.setText("Forget Password");
        forget.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                forgetActionPerformed(evt);
            }
        });
        getContentPane().add(forget, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 260, 90, 20));

        Name1.setFont(new java.awt.Font("Bahnschrift", 0, 14)); // NOI18N
        Name1.setText("Name:");
        getContentPane().add(Name1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 140, -1, -1));

        Name.setFont(new java.awt.Font("Bahnschrift", 0, 14)); // NOI18N
        Name.setText("Password:");
        getContentPane().add(Name, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 200, -1, -1));

        adminicon.setForeground(new java.awt.Color(255, 255, 255));
        adminicon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Image/adminicon.png"))); // NOI18N
        adminicon.setToolTipText("");
        getContentPane().add(adminicon, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 300, 430));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void loginButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginButtonActionPerformed
          String inputUserName = new String(txtUsername.getText());
          fetchDataFromDatabase(inputUserName);
          String inputPassword = new String(txtPassword.getPassword());
        if (inputPassword.equals(expectedPassword) ) {
            homePage.setVisible(true);
            homePage.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            this.dispose(); // Close the login frame
        } else {
            JOptionPane.showMessageDialog(null, "Password or User Name is incorrect!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_loginButtonActionPerformed

    private void txtUsernameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtUsernameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtUsernameActionPerformed

    private void txtPasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPasswordActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPasswordActionPerformed

    private void forgetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_forgetActionPerformed
     JOptionPane.showMessageDialog(this, "For Reset Your Password Call-01751998178");
    }//GEN-LAST:event_forgetActionPerformed

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }

        java.awt.EventQueue.invokeLater(() -> {
            new login().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Name;
    private javax.swing.JLabel Name1;
    private javax.swing.JLabel adminicon;
    private javax.swing.JButton forget;
    private javax.swing.JButton loginButton;
    private javax.swing.JPasswordField txtPassword;
    private javax.swing.JTextField txtUsername;
    // End of variables declaration//GEN-END:variables
}
