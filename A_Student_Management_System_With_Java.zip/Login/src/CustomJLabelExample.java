import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class CustomJLabelExample extends JFrame {
    public CustomJLabelExample() {
        initComponents();
    }

    private void initComponents() {
        setLayout(new FlowLayout());

        // Create and add multiple JLabels
        for (int i = 1; i <= 5; i++) {
            JLabel label = createLabel("Label " + i);
            add(label);

            // Add a mouse listener to each label
            label.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    // Change the color of the clicked label
                    label.setForeground(Color.RED);
                }
            });
        }

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Arial", Font.PLAIN, 16));
        label.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return label;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CustomJLabelExample());
    }
}
